
#!/bin/bash

gcc -o ex3 ex3.c

./ex3
