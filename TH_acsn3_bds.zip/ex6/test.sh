
#!/bin/bash

gcc -o ex6 ex6.c

./ex6
