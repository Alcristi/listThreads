
#!/bin/bash

gcc -o ex2 ex2.c

./ex2 
