
#!/bin/bash

gcc -o ex5 ex5.c

./ex5
