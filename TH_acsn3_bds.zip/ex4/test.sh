
#!/bin/bash

gcc -o ex4 ex4.c

./ex4
